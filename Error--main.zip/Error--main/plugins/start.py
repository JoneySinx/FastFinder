import random

from hydrogram import Client, filters
from hydrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from info import PICS, script
from utils import get_wish


# ======================================================
# 🔘 START BUTTONS (MINIMAL)
# ======================================================

def start_buttons():
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("👨‍🚒 Help", callback_data="help")
            ]
        ]
    )


# ======================================================
# 🚀 /start COMMAND (NORMAL - NOT FILE DELIVERY)
# ======================================================

@Client.on_message(
    filters.command("start") & 
    filters.private & 
    ~filters.regex(r"file_")  # ✅ Exclude file delivery
)
async def start_cmd(client, message):
    await message.reply_photo(
        photo=random.choice(PICS),
        caption=script.START_TXT.format(
            message.from_user.mention,
            get_wish()
        ),
        reply_markup=start_buttons()
    )
